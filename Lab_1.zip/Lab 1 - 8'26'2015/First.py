## first.py
## CSCI 222 - Lab 01 - 1/14/08
## Eduardo R Abreu
## First Python Program

def main():
    print("Programming is fun, but it is not a spectator sport.")
    print("I look forward to learning to control this computer through programming!" )
