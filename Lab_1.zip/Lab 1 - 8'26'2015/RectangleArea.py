## RectangleArea.py
## Eduardo R Abreu
## This program calculates the area of a rectangle.

def main():
    #Set length and width
    length = eval(input("Enter the length: "))
    width = eval(input("Enter the width: "))

    #Calculate area
    area = length * width

    #Display area
    print ("Area =", area)
