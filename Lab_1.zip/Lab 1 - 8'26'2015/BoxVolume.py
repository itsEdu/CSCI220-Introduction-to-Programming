## BoxVolume.py
## Eduardo R Abreu
## This program calcualtes the volume of a rectangular solid.

def main():
    #Intro message
    print("I can calculate the volume of a box! Lets begin...")

    #Varibles and calculation
    length = eval(input("Enter the length of the box: "))
    width = eval(input("Enter the width of the box: "))
    height = eval(input("Enter the height of the box: "))
    volume = length * width * height

    #Output of the volume
    print("The volume =", volume)
