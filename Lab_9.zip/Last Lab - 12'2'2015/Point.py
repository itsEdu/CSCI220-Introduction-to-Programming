class Point:
    def __init_(self, x, y):
        self.x = 0
        self.y = 0

    def getX(self):
        return self.x

    def getY(self):
        return self.y

    def setX(self, x):
        self.x = x

    def setY(self, y):
        self.y = y

    def __str__(self):
        point = print("Point(" + str(self.x) + ", " + str(self.y) + ")")
        return point
    
