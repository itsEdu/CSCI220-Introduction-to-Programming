# CSCI 220L - Lab 12
#
# Name 1: Eduardo R Abreu
#
# Name 2: Wendell Roberson
#
#Binary search is instant. Linear takes a longer time.
#
#Python's sorting is WAY faster.

def readData(filename):
    file = open(filename, "r")
    numberList = []
    for lines in file:
        numbers = lines.split()
        for item in numbers:
            number = eval(item)
            numberList.append(number)
    return numberList

def isInLinear(searchVal, values):
    isLinear = False
    doneSearch = False
    lenList = len(values)
    i = 0
    while doneSearch == False and lenList > i:
        if values[i] == searchVal:
            isLinear = True
            doneSearch = True
        else:
            i += 1
    print(isLinear)
    return isLinear

def isInBinary(searchVal, values):
    low = 0
    high = len(values) - 1
    while low <= high:
        mid = (low + high) //2
        item = values[mid]
        if searchVal == item:
            return True
        elif searchVal < item:
            high = mid - 1
        else:
            low = mid + 1
    return False

def selectionSort(values):
    lenList = len(values)
    for bottom in range(lenList - 1):
        smaller = bottom
        for i in range(bottom + 1, lenList):
            if values[i] < values[smaller]:
                smaller = i
            values[bottom], values[smaller] = values[smaller], values[bottom]

def main():
    values = readData("dataSorted.txt")
    #searchVal = eval(input("Give me a number to find: "))
    #isInLinear(searchVal, values)
    i#sInBinary(searchVal, values)
    selectionSort(values)
    
main()
