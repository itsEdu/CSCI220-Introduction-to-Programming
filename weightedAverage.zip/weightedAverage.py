# Name: Eduardo R Abreu
# fallGreeting.py
#
# Problem: This program will output the total time of a CD.
#
# Certification of Authenticity:  
# I certify that this lab is entirely my own work.

def main():
    #Asks for the file name and opens it
    file = input("What is the name of the file with the grades? ")
    infile = open(file, "r")

    #Constants
    HUNDRED = 100

    #Variables
    average = 0
    total = 0
    students = 0
    weightAndGrade = 0

    #Loop for lines in file
    for line in infile:
        #Splits the lines into a list
        splitLines = line.split()

        #First name
        firstName = splitLines[0]

        #Last name
        lastName = splitLines[1]
        
        #Add one to the number of students in the file
        students += 1

        for i in range(2, len(splitLines), 2):
            #Weights
            weight = eval(splitLines[i])

            #Grades
            grade = eval(splitLines[i+1])

            #Total student weight and grades
            weightAndGrade += weight * grade

        #Calculate student's average
        weightAndGrade = weightAndGrade / 100
        
        #Print, per student, average and name
        print(firstName + " " + lastName + "'s average: {:.1f}".format(weightAndGrade))

        #Total of all grades
        total += weightAndGrade

    print()
    #Get the average for the class
    average = total / students

    #Print the class average
    print("The class average is: {:.1f}".format(average))
    
    infile.close()    
    
main()
