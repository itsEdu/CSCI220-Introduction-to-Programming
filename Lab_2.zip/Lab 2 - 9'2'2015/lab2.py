## lab2.py
## Purpose: Solves problems assigned in Lab 2
## Name: Eduardo R Abreu

import math

def kilometersToMiles():
    #Variables
    KILOMETERS_TO_MILES = 1.61
    
    #Explain what the function does.
    print("This function converts kilometers to miles.")
    
    #Get input of number of kilometers.
    kilometers = eval(input("Amount of kilometers traveled: "))
    
    #Calculate number of miles.
    miles = kilometers / KILOMETERS_TO_MILES
    
    #Output the number of miles.
    print("The number of miles is:",miles)
    print("-----------------------------------------------------------")
    
def shootingPercentage():
    #Explain what the function does.
    print("This function displays a player's shooting percentage.")
    
    #Ask for the player's total shots.
    totalShots = eval(input("Number of shots taken: "))
    
    #Ask for the number of shots made.
    totalShotsMade = eval(input("Number of shots made: "))
    
    #Calculate shooting percentage.
    shootingPercentage = (totalShotsMade / totalShots) * 100

    #Output the player's shooting percentage.
    print("Player's shooting percentage: "+str(shootingPercentage)+"%")
    print("-----------------------------------------------------------")

def coffee():
    #Variables
    overhead = 1.50
    shipping = 0.86
    perLbs = 10.50
    
    #Explain what the function does.
    print("This function calculates the cost of oders for customers.")

    #Get number of orders.
    orderNum = eval(input("Number of orders: "))
    print()

    #Loop for number of orders.
    for i in range(orderNum):
        
        #Get pounds for order.
        lbsNum = eval(input("Number of pounds in order: "))

        #Calculate cost for order.
        costOfOrder = ((lbsNum*perLbs)+(lbsNum*shipping))+overhead

        #Output cost of the order.
        print("The cost of order "+str(i + 1)+" is: "+str(costOfOrder))
        print()    
    print("-----------------------------------------------------------")

def triangleArea():
    #Explain what the function does.
    print("This function calculates the area of a triangle.")

    #Get the length of side a.
    aSide = eval(input("Measure of side 'a': "))

    #Get the length of side b.
    bSide = eval(input("Measure of side 'b': "))

    #Get the length of side c.
    cSide = eval(input("Measure of side 'c': "))

    #Calculate sides.
    sides = (aSide + bSide + cSide) / 2

    #Calculate area.
    area = math.sqrt(sides*(sides-aSide)*(sides-bSide)*(sides-cSide))

    #Output the area.
    print("The area of this triangle is: " + str(area))
    print("-----------------------------------------------------------")

def sumSquares():
    #Variables
    total = 0
    
    #Explain what the function does.
    print("This function calculates the sum of squares in given range")

    #Get starting number of range.
    start = eval(input("Starting number of range: "))

    #Get ending number of range.
    stop = eval(input("Ending number of range: "))

    #Calculate sum of the squares.
    for i in range(start, stop+1):
        total = total + i**2

    #Output the sum of the squares.
    print("\nThe total sum of the squares is:",total)
    print("-----------------------------------------------------------")

def power():
    #Variables
    total = 1
    
    #Explain what the function does.
    print("This function calculates the power of numbers.")

    #Get the base.
    base = eval(input("The base number: "))

    #Get the exponent.
    exponent = eval(input("The exponent: "))

    #Loops based on exponent number.
    for i in range(exponent):
        total = total * base

    #Output total.
    print()
    print("The answer is: " + str(total))
    print("-----------------------------------------------------------")

def main():    
    kilometersToMiles()
    shootingPercentage()
    coffee()
    triangleArea()
    sumSquares()
    power()
    
main()



    
    

    

    

