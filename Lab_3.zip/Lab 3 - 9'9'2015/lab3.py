"""
Lab3.py

Name: Eduardo R Abreu
"""


def average():
    #Variables
    total = 0

    #Tells the user what the program does
    print("\nThis program averages your class grades.")

    #Ask the number of grades to average
    numberOfGrades = eval(input("Number of grades to input: "))

    #Loop to find each homework grade
    for i in range(numberOfGrades):
        hw = eval(input("Enter your grade on HW" + str(i+1) + ": "))
        total = total + hw
        
    #Average the grades
    average = total / numberOfGrades

    #Outputs average
    print("The average is: " + str(average))

def fibonacci():
    #Variables
    firstNumber = 0
    secondNumber = 1
    math = 1
    
    #Tells the user what the program does
    print("\nThis program computes the fibonacci sequence to your number.")

    #Gets the user input for the nth number
    length = eval(input("The length of the sequence: "))

    
    print(firstNumber)

    #Loop the sequence
    for i in range(length-1):
        math = firstNumber + secondNumber

        print(secondNumber)

        firstNumber = secondNumber
        secondNumber = math

def newton():
    #Variables
    x = 0

    #Tells the user what the program does
    print("\nThis program gives the approximation of a square root.")

    #Get number used from user
    x = eval(input("Number to be used: "))

    approximation = x / 2

    #Get number of times to approximate
    numberOfTimes = eval(input("Number of times to appoximate: "))

    #Loop nth times
    for i in range(numberOfTimes):
        approximation = (approximation + (x / approximation)) / 2

    print("The square root of " + str(x) +" is: " + str(approximation))


def sequence():
    #Variables
    math = 0
    startNumber = 2
    secondNumber = startNumber

    #Tells the user what the program does
    print("\nAsk the user for the number of terms in a sequence.")

    #Get length of sequence
    sequenceLength = eval(input("Length of the sequence: "))

    #Computing loop
    for i in range(sequenceLength):
        rem = (i+1)%2
        math = math + (rem * 2)
        print(math, end = " ")

def pi():
    #Variables
    mathTop = 0
    mathBottom = 1
    startNumber = 2
    secondNumber = startNumber
    pi = 1

    #Tells the user what the program does
    print("\nThis function approximates pi.")

    #Get length of sequence
    sequenceLength = eval(input("Length of the sequence: "))
    
    #Computing loop
    for i in range(sequenceLength):
        remTop = (i+1)%2
        mathTop = mathTop + (remTop * 2)
        
        remBottom = (i)%2
        mathBottom = mathBottom + (remBottom * 2)
        
        numerator = mathTop
        denominator = mathBottom

        pi = ((numerator / denominator) * pi)
    print("Pi is approximately: " + str(pi*2))
    
def main():
    #average()
    #fibonacci()
    #newton()
    sequence()
    #pi()

main()
