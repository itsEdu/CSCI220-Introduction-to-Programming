# Lab6.py
# Name 1: Eduardo R Abreu
# Name 2: Holden P Lucas

def nameReverse():
    name = input("What is your name? ")
    nameSplit = name.split()
    lastname = nameSplit[1]
    firstname = nameSplit[0]

    print("" + lastname + ", " + firstname )

def companyName():
    domain = input("Enter domain name: ")
    domainSplit = domain.split(".")
    company = domainSplit[1]
    print(company)

def initials():
    numNames = eval(input("Number of names to input: "))

    for i in range(numNames):
        firstName = input("What is the name of student " + str((i+1)) + "? ")
        lastName = input("What is " + firstName + "'s last name? ")
        initials = (firstName[0] + lastName[0]).upper()

        print(firstName + "'s initials are " + initials + ".")

def names():
    nameList = input("Please enter a list of names, first and last, separated by commas: ")
    commaSplit = nameList.count(",")
    names = nameList.split(",")
    
    for name in names:
        singleName = name.split()
        firstName = singleName[0]
        secondName = singleName[1]

        firstInitial = firstName[0]
        secondInitial = secondName[0]

        print(firstInitial + secondInitial)

def thirds():
    numberSentences = eval(input("Enter the number of sentences to be input: "))

    for i in range(numberSentences):
        sentence = input("Enter sentence #" + str(i+1) + ": ")
        scramble = sentence[2::3]

        print(scramble)
        

def wordCount():
    numberSentences = eval(input("Enter the number of sentences to be input: "))

    for i in range(numberSentences):
        sentence = input("Enter sentence #" + str(i+1) + ": ")
        words = sentence.split()
        wordCount = len(words)

        print("The word count is: " + str(wordCount))

def wordAverage():
    total = 0 
    numberSentences = eval(input("Enter the number of sentences to be input: "))

    for i in range(numberSentences):
        sentence = input("Enter sentence #" + str(i+1) + ": ")
        words = sentence.split()

        for j in range(len(words)):
            length = len(words[j])
            total = total + length

        average = total / len(words)
        
        print(average)

def gradeToLetter():
    numericGrade = eval(input("What is your numeric grade? "))
    grades = "FFFFFFDCBAA"

    numberGrade = numericGrade // 10

    letterGrade = grades[numberGrade]

    print(letterGrade)
    
    
        
def main():
    #nameReverse()
    #companyName()
    #initials()
    #names()
    #thirds()
    #wordCount()
    #wordAverage()
    gradeToLetter()
    
main()
