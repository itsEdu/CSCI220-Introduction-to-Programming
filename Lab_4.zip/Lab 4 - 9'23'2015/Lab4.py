"""
Lab 4 - Graphics
Name: Eduardo R Abreu
"""


## Discussion #3, Graphics chapter of Zelle text
## Moves a circle based on user clicks
## Comments added: RHS

from graphics import *
from math import *

def squares():
    """
    Modify the following function to:

    Draw squares (20 X 20) instead of circles. Make sure that the center of the square
    is at the point where the user clicks. Make the window 400 by 400.

      Have each successive click draw an additional square on the screen (rather
    than just moving the existing one).

    Display a message on the window "Click again to quit" after the loop, and
    wait for a final click before closing the window.
    """
    #Creates a graphical window
    width = 400
    height = 400
    win = GraphWin("Lab 4: Square", width, height)

    #number of times user can move circle
    numClicks = 5

    #create a space to instruct user
    instPt = Point(width/2, height-10)
    instructions = Text(instPt,"Click to move square")
    instructions.draw(win)

    #builds a square
    topLeftPoint = Point(50, 50)
    bottomRightPoint = Point(70, 30)
    shape = Rectangle(topLeftPoint, bottomRightPoint)
    shape.setOutline("red")
    shape.setFill("red")
    shape.draw(win)

    #allows the user to click multiple times to move the
    #circle
    for i in range(numClicks):
        p = win.getMouse()
        c = shape.getCenter() #center of circle

        #move amount is distance from center of circle to the
        #point where the user clicked
        shape2 = shape.clone()
        shape2.draw(win)
        
        dx = p.getX() - c.getX()
        dy = p.getY() - c.getY()
        shape.move(dx, dy)

    instructions.setText("Click again to close")
    win.getMouse()
    win.close()

def rectangle():
    """
    Display the numerical output in the graphics window – don't use print.
    Ask the user to click to end the program, and be sure to close the
    window at the end. Make the window 400 by 400.

    From programming Exercise 9 (p. 119)
    Input: Two mouse clicks for the opposite corners of a rectangle.
    Output: Draw the rectangle. Show the perimeter and area of the rectangle.

    area = (length)(width)
    perimeter = 2 (length + width)
    """

    #Creates a graphical window
    width = 400
    height = 400
    win = GraphWin("Lab 4: Rectangle", width, height)

    #number of times user can move circle
    numClicks = 2

    #create a space to instruct user
    instPt = Point(width/2, height-20)
    instructions = Text(instPt,"Click to draw the rectangle")
    instructions.draw(win)

    #Get the points of the rectangle
    click = win.getMouse()
    clickX = click.getX()
    clickY = click.getY()
    
    click2 = win.getMouse()
    click2X = click2.getX()
    click2Y = click2.getY()

    #Calculate area
    length = abs((click2X - clickX))
    width = abs((click2Y - clickY))
    
    area = length * width
    perimeter = 2*(length + width)
    
    instructions.setText("The area is: " + str(area) + "px\n" +
                         "The perimeter is: " + str(perimeter) + "px")
    
    #Draw the rectangle
    shape = Rectangle(click, click2)
    shape.setOutline("red")
    shape.setFill("red")
    shape.draw(win)
    
    win.getMouse()
    win.close()
    
def circle():
    """
    Write a funtion called circle() to draw a circle. The first mouse
    click determines the center of the circle. The second mouse click
    determines a point on its circumference. Use the Euclidean distance
    formula to determine the length of the radius. Ask the user to click
    to end the program, and close the window at the end.
    """

    #Creates a graphical window
    width = 400
    height = 400
    win = GraphWin("Lab 4: Cirlce", width, height)

    #create a space to instruct user
    instPt = Point(width/2, height-20)
    instructions = Text(instPt,"Click to set the center of circle\n" +
                        "Click again to set the radius")
    instructions.draw(win)

    mouse = win.getMouse()
    mouseX = mouse.getX()
    mouseY = mouse.getY()
    
    mouse2 = win.getMouse()
    mouse2X = mouse2.getX()
    mouse2Y = mouse2.getY()
    
    #Get the center of the circle
    center = Point(mouseX, mouseY)

    radius = sqrt((mouse2X-mouseX)**2+(mouse2Y-mouseY)**2)
    
    #builds a circle
    shape = Circle(center, radius)
    shape.setOutline("red")
    shape.setFill("red")
    shape.draw(win)

    win.getMouse()
    win.close()

def pi2():
    """
    Write a function, pi2(), to approximate the value of pi by summing
    the terms of this series:
    4/1 – 4/3 + 4/ 5 – 4/7 + 4/9 – 4/11 + ….
    The program should prompt the user for n, the number of terms to sum,
    and then output the sum of the first n terms of this series.  Have
    your function subtract from the value of math.pi to see how accurate
    it is.
    """

    #Variables and constants
    NUMERATOR = 4
    denominator = 1
    fraction = 0
    total = 0

    #Ask user for amount of terms
    n = eval(input("How many terms to calculate? "))

    for i in range(n):
        fraction = NUMERATOR / denominator
        total = fraction - total
        denominator += 2
        fraction = fraction * (-1)

    difference = pi - total
    print(difference)
    print(total)
    print(pi)

def main():
    #squares()
    #rectangle()
    #circle()
    pi2()

main()
