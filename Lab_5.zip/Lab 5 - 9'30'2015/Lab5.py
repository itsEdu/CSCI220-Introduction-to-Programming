# Lab5.py
# Name 1: Eduardo R Abreu
# Name 2: Tyler R Lyles

from graphics import *
from math import *

def cupConverter():
    # Author: RoxAnn H. Stalvey, modified by Walter Pharr
    # Illustrates getting numeric input through graphics window
    winWidth = 300
    winHeight = 200
    win = GraphWin("Convert cups to milliliters", winWidth, winHeight)

    #Specify the message for the input box
    boxDesc = Text(Point(100, 50), "Input cups: ")
    boxDesc.draw(win)

    #Create the Entry object and set its default text to a number
    #  allowing the user to see what type of value is expected
    inp = Entry(Point(200, 50), 5)
    inp.setText("0")
    inp.draw(win)

    #Create a Text object for outputting the result
    output = Text(Point(150, 150), "")
    output.draw(win)

    #Creating the output text 'ml'
    mlOutput = Text(Point(150, 170), "")
    mlOutput.draw(win)

    #This button isn't necessary, but it makes a nice point for the user
    #  to click.  If you click anywhere in the window, the code reacts
    #  the same way.
    btPtX = winWidth/2
    btPtY = winHeight/2
    button = Text(Point(btPtX, btPtY), "Click")
    button.draw(win)
    border = Rectangle(Point(btPtX-35, btPtY-20), Point(btPtX+35, btPtY+20))
    border.draw(win)

    # Wait for a mouse click
    win.getMouse()

    # Discover intput and convert it to a number
    # If numeric input wasn't needed, simply omit the eval()
    cups = eval(inp.getText())

    #Calculate milliliter equivalent here
    OUNCES = 8
    ML = 29.57
    ounces = cups * OUNCES
    math = ounces * ML

    # Display output and change button
    output.setText("Cups = " + str(cups))
    mlOutput.setText("Cups -> mL = " + str(math) + "mL")
    button.setText("Quit")
    
    # Wait for another click to exit
    win.getMouse()
    win.close()


def target():
    winWidth = 500
    winHeight = 500
    win = GraphWin("Archery Target", winWidth, winHeight)
    win.setBackground("Pink")

    # Add code here to get the dimensions and draw the target
    center= Point(winWidth/2 , winHeight/2)
    
    cirWhite= Circle(center, winWidth/2)
    cirWhite2= Circle(center, winWidth/2.2) 
    cirWhite.setFill("White")
    cirWhite.draw(win)
    cirWhite2.draw(win)

    cirBlack= Circle(center, winWidth/2.5)
    cirBlack2= Circle(center, winWidth/2.86)
    cirBlack.setFill("Black")
    cirBlack.draw(win)
    cirBlack2.setOutline("white")
    cirBlack2.draw(win) 

    cirBlue= Circle(center, winWidth/3.33)
    cirBlue2= Circle(center, winWidth/4) 
    cirBlue.setFill("Blue")
    cirBlue.draw(win)
    cirBlue2.draw(win)

    cirRed= Circle(center, winWidth/5)
    cirRed2= Circle(center, winWidth/6.67)
    cirRed.setFill("Red")
    cirRed.draw(win)
    cirRed2.draw(win) 

    cirYellow= Circle(center, winWidth/10)
    cirYellow2= Circle(center, winWidth/20)
    cirYellow.setFill("Yellow")
    cirYellow.draw(win)
    cirYellow2.draw(win)

    text = Text(Point(winWidth/8.33,winHeight/1.05) , "Click to close.")
    text.draw(win)

    # Wait for another click to exit
    win.getMouse()
    win.close()



def triangle():
    winWidth = 500
    winHeight = 500
    win = GraphWin("Draw a Triangle", winWidth, winHeight)

    # Add code here to accept the mouse clicks, draw the triangle.
    # and display its area in the graphics window.


    # User Draws triangle
    instPt = Point(winWidth/2, winHeight/1.18)
    perPt = Point(winWidth/2, winHeight/1.12)
    areaPt = Point(winWidth/2, winHeight/1.06)
    instructions = Text(instPt, "Click three points.")
    perimeterText = Text(perPt, "")
    areaText = Text(areaPt, "")
    instructions.draw(win)
    
    pt1 = win.getMouse()
    pt1X = pt1.getX()
    pt1Y = pt1.getY()

    pt2 = win.getMouse()
    pt2X = pt2.getX()
    pt2Y = pt2.getY()

    pt3 = win.getMouse()
    pt3X = pt3.getX()
    pt3Y = pt3.getY()

    polygon = Polygon( pt1, pt2, pt3)
    polygon.setFill("Purple")
    polygon.draw(win)

    length1dx = pt2X - pt1X
    length1dy = pt2Y - pt1Y
    
    length2dx = pt3X - pt2X
    length2dy = pt3Y - pt2Y
    
    length3dx = pt1X - pt3X
    length3dy = pt1Y - pt3Y

    length1 = sqrt(((length1dx)**2) + ((length1dy)**2))
    length2 = sqrt(((length2dx)**2) + ((length2dy)**2))
    length3 = sqrt(((length3dx)**2) + ((length3dy)**2))

    #Perimeter math.
    perimeter = length1 + length2 + length3
    perimeterText.setText("Perimeter: " + str(perimeter) + "px")
    perimeterText.draw(win)

    #Area math.
    s = (length1 + length2 + length3) / 2
    area = sqrt(s*(s-length1)*(s-length2)*(s-length3))
    areaText.setText("Area: " + str(area) + "px")
    areaText.draw(win)
    
    instructions.setText("Click again to close.")

    # Wait for another click to exit
    win.getMouse()
    win.close()

def colorShape():
    '''Create code to allow a user to color a shape by entering rgb amounts'''

    #create window
    winWidth = 400
    winHeight = 400
    win = GraphWin("Color Shape", winWidth, winHeight)
    win.setBackground("white")

    #create text instructions
    msg = "Enter color values between 0 - 255\nClick window to color shape"
    inst = Text(Point(winWidth/2, winHeight-20), msg)
    inst.draw(win)

    #create circle in window's center
    shape = Circle(Point(winWidth/2, winHeight/2 - 30), 50)
    shape.draw(win)

    #redTexPt is 50 pixels to the left and forty pixels down from center
    redTextPt = Point(winWidth/2 - 50, winHeight/2 + 40)
    redText = Text(redTextPt, "Red: ")
    redText.setTextColor("red")
    inp1 = Entry(Point(winWidth/2, winHeight/2+40), 5)
    inp1.setText("0")
    inp1.draw(win)

    #greenTextPt is 30 pixels down from red
    greenTextPt = redTextPt.clone()
    greenTextPt.move(0,30)
    greenText = Text(greenTextPt, "Green: ")
    greenText.setTextColor("green")
    inp2 = Entry(Point(winWidth/2, winHeight/2+40), 5)
    inp2.move(0,30)
    inp2.setText("0")
    inp2.draw(win)

    #blueTextPt is 60 pixels down from red
    blueTextPt = redTextPt.clone()
    blueTextPt.move(0,60)
    blueText = Text(blueTextPt, "Blue: ")
    blueText.setTextColor("blue")
    inp3 = Entry(Point(winWidth/2, winHeight/2+40), 5)
    inp3.move(0,60)
    inp3.setText("0")
    inp3.draw(win)

    #display rgb text
    redText.draw(win)
    greenText.draw(win)
    blueText.draw(win)

    win.getMouse()
    for i in range(5):
        #Fill circle color
        shape.setFill(color_rgb(eval(inp1.getText()), eval(inp2.getText()), eval(inp3.getText())))
        shape.undraw()
        shape.draw(win)
        win.getMouse()
    

    # Wait for another click to exit
    win.getMouse()
    win.close()
    
def main():
    #cupConverter()
    #target()
    #triangle()
    colorShape()


main()




