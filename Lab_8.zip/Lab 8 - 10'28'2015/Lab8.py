# CSCI 220L - Lab 8 Solutions
#
# Name 1: Eduardo R Abreu
#
# Name 2: Zach Macaulay
#

import math

# Chapter 6, Exercise 3
def sphereArea(radius):
    """
    Function to compute and return the area (A = 4πr^2) of a sphere.
    """
    area = (4*math.pi*radius**2)
    return area
    

def sphereVolume(radius):
    """
    Function to compute and return the volume (V = 4/3πr^3) of a sphere.
    """
    volume = 4 / (3 * math.pi * radius ** 3)
    return volume
    

def testSphereFunctions():
    """
    Prompt user for radius of a sphere and output the area and volume
    using functions
    """
    userInput = eval(input("What is the radius? "))
    area = sphereArea(userInput)
    volume = sphereVolume(userInput)
    print("Area =", area, "\nVolume =", volume)
    print()
    

#testSphereFunctions()

# Chapter 6, Exercise 4
def sumN(n):
    """
    Function to compute and return the sum of the first N natural numbers.
    """
    total = 0
    for i in range(n):
        total += (i+1)
    return total


def sumNCubes(n):
    """
    Function to compute and return the sum of the cubes of the first N natural numbers.
    """
    total = 0
    for i in range(n):
        total = (i+1)**3 + total
    return total


def testSumFunctions():
    """
    Prompt user for n and print sum of first n natural numbers and the sum
    of the cubes of first n numbers using functions.
    """
    n = eval(input("Enter a number: "))
    sumNatural = sumN(n)
    sumCubed = sumNCubes(n)
    print("Natural sum =", sumNatural, "\nCubed sum =", sumCubed)
    print()
    


#testSumFunctions()

# chapter 6, exercise 11
def squareEach(nums):
    """
    Function to square each number in a list. Returns nothing.
    """
    for i in range(len(nums)):
        nums[i] = nums[i] ** 2
        
# chapter 6, exercise 12
def sumList(nums):
    """
    Function to add the numbers in a list. Returns the sum.
    """
    total = 0
    for i in range(len(nums)):
        total += nums[i]
    return total

# chapter 6, exercise 13
def toNumbers(strList):
    """
    Function to convert a list of numbers in string form to
    numerical form. Returns nothing.
    """
    for i in range(len(strList)):
       strList[i] = eval(strList[i])

# chapter 6, exercise 14
def solve():
    """
    Function to read numbers from a file and display the sum of
    the squares of the numbers. Uses the three previous functions.
    """
    infile = open("numList.txt")
    readFile = infile.read()
    fileSplit = readFile.split()
    
    toNumbers(fileSplit)
    squareEach(fileSplit)
    finish = sumList(fileSplit)

    print(finish)
    infile.close()

def sumOfSquares():
    """
    Code to test exercise 11 - square numbers in a list
    """
    values = [1, 2, 3, 4, 5]
    squareEach(values)
    print(values)
    
    """
    Code to test exercise 12 - sum numbers in a list
    """
    print(sumList(values))
    
    """
    Code to test exercise 13 - sum list of strings to numbers
    """
    stringValues = ["1","2","3","4","5"]
    toNumbers(stringValues)
    print(stringValues)

    """
    Code to test exercise 14 - display the sum of the squares of the
    numbers on a file, using the three previous functions.
    """
    solve()
    
sumOfSquares()

