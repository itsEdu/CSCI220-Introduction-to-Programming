# Name: Eduardo R Abreu
# hangman.py
#
# Problem: This program is a recreation of the children's game hangman.
#
# Certification of Authenticity:  
# I certify that this is entirely my own work.

from random import *
from graphics import *

def introTextAndFile(win):
    #Instructions.
    instText = "Type the name of the file with the words."
    instructions = Text(Point(win.width/2, win.height/4), instText)
    instructions.draw(win)
    #Grab the file's name that has the words.
    fileEntry = Entry(Point(win.width/2, win.height/3), 10)
    fileEntry.draw(win)
    win.getMouse()
    file = fileEntry.getText()
    fileEntry.undraw()
    instructions.undraw()
    return file
    
def readWordList(file):
    #Creates a list.
    wordList = []
    infile = open(file, "r")
    for line in infile:
        #Splits lines and adds words into list.
        word = line.split()
        wordList.append(word)
    return wordList

def randomWordPicked(wordList):
    #Chooses random word out of the list.
    random = randint(0, (len(wordList)-1))
    secretWord = wordList[random][0]
    return secretWord

def guessedWordReturn(secretWord, win):
    gameState = 0
    #Number of starting guessses.
    guessLeft = 7
    stillGuessing = True
    #Boolean for is word guessed or not.
    wordGuessed = False
    #Creates a list that will handle the holding of the word's letters.
    wordList = []
    #List of guessed letters.
    guessedLetters = []
    #Creates the empty spaces in the list.
    for i in range(0, len(secretWord)):
        wordList.append("_")
    #Joins the spaces into a string
    spaceList = " ".join(wordList)
    #Outputs the spaces to show the number of letters in word.
    print(spaceList)
    #Text creation and drawing.
    wordListText = " ".join(wordList)
    wordListTextObject = Text(Point(125,600), wordListText)
    wordListTextObject.setSize(16)
    wordListTextObject.draw(win)
    numGuessText = "You have " + str(guessLeft) + " guesses left."
    numGuessTextObject = Text(Point(125,650), numGuessText)
    numGuessTextObject.draw(win)
    lettersUsedText = "Letters guessed: " + "".join(guessedLetters)
    lettersUsedTextObject = Text(Point(400, 200), lettersUsedText)
    lettersUsedTextObject.draw(win)
    letEntryText = "Give me a letter:"
    letEntryTextObject = Text(Point(win.width/1.5, 350), letEntryText)
    letEntryTextObject.draw(win)
    letEntryText2 = "Click to enter."
    letEntryTextObject2 = Text(Point(win.width/1.5, 450), letEntryText2)
    letEntryTextObject2.draw(win)
    #Game loop.
    while stillGuessing == True and wordGuessed == False:
        updateGUI(win, gameState)
        print()
        #States the letters that have been guessed.
        print("Letters guessed: " + "".join(guessedLetters), end = " ")
        print()
        #Asks for a letter.
        letterEntry = Entry(Point(win.width/1.5, 400), 1)
        letterEntry.draw(win)
        win.getMouse()
        guessLetter = letterEntry.getText()
        letterEntry.undraw()
        if letterIsNotGuessed(guessedLetters, guessLetter):
            #Checks to see if the letter is in the word.
            for i in range(len(secretWord)):
                if secretWord[i] == guessLetter:
                    wordList[i] = guessLetter
            for item in wordList:
                print(item, end = " ")
            #Checks to see if the list of letters together = the word.
            if "".join(wordList) == secretWord:
                wordGuessed = True
            #If the letter matches the letter in the word, don't take points.
            if secretWord.find(guessLetter) >= 0:
                guessLeft = guessLeft
            #Else do.
            else:
                guessLeft -= 1
                gameState += 1
            print()
            if wordGuessed == False:
                numGuessText2 = "You have " + str(guessLeft) + " guesses left."
                print("You have " + str(guessLeft) + " guesses left.")
            else:
                print("You guessed the word!")
        else:
            print("You've already guessed this letter!")
            print("You have " + str(guessLeft) + " guesses left.")
        if guessLeft <= 0:
            stillGuessing = False
        #Adds the letter in to the guessed list.
        guessedLetters.append(guessLetter)
        lettersUsedText2 = "Letters guessed: " + "".join(guessedLetters)
        wordListText2 = " ".join(wordList)
        wordListTextObject.setText(wordListText2)
        numGuessTextObject.setText(numGuessText2)
        lettersUsedTextObject.setText(lettersUsedText2)
        if stillGuessing == False or wordGuessed == True:
            gameState = 7
            updateGUI(win, gameState)
            #undraws all text.
            wordListTextObject.undraw()
            numGuessTextObject.undraw()
            lettersUsedTextObject.undraw()
            letEntryTextObject.undraw()
            letEntryTextObject2.undraw()
            #creates the question text.
            text = "Do you want to play again? "
            textObject = Text(Point(win.width/2, win.height/2), text)
            textObject.draw(win)
            #buttons and their text.
            yesButton = Rectangle(Point(315,370), Point(360,390))
            noButton = Rectangle(Point(375,370), Point(400,390))
            centerYes = yesButton.getCenter()
            centerNo = noButton.getCenter()
            yesButtonTextObject = Text(centerYes, "YES")
            noButtonTextObject = Text(centerNo, "NO")
            yesButtonTextObject.draw(win)
            noButtonTextObject.draw(win)
            yesButton.draw(win)
            noButton.draw(win)
            #button borders check.
            click = win.getMouse()
            clickX = click.getX()
            clickY = click.getY()
            if clickX >= 315 and clickX <=360 and clickY >= 370 and clickY <= 390:
                yesButtonTextObject.undraw()
                yesButton.undraw()
                noButtonTextObject.undraw()
                noButton.undraw()
                win.close()
                main()
            if clickX >= 375 and clickX <= 400 and clickY >= 370 and clickY <= 390:
                yesButtonTextObject.undraw()
                yesButton.undraw()
                noButtonTextObject.undraw()
                noButton.undraw()
                win.close()

def letterIsNotGuessed(guessedLetters, guessLetter):
    print(guessLetter)
    print(guessedLetters)
    guessed = True
    for item in guessedLetters:
        if item == guessLetter:
            guessed = False
    return guessed

def updateGUI(win, gameState):
    #Made this just as a test for cases in python.
    #Debug print to shell.
    print(".-=||UPDATE GUI||=-.")
    #Resembles a switch/case from Java.
    switcher = {
        0: "hang0.png",
        1: "hang1.png",
        2: "hang2.png",
        3: "hang3.png",
        4: "hang4.png",
        5: "hang5.png",
        6: "hang6.png",
        7: "hang7.png",
        }
    #Image using the "switch/case."
    gallows = Image(Point(125, 350), switcher.get(gameState, "hang7.png"))
    gallows.draw(win)
    print(gameState)
            
def hangmanGUI():
    #Variables.
    width = 600
    height = 700
    #Creates the window.
    win = GraphWin("Hangman", width, height)
    #Creates title text.
    title = Text(Point(width/2, 50), "Hangman")
    title.setTextColor("blue")
    title.setSize(24)
    title.draw(win)

    return win

def getPoints(win):
    for i in range(20):
        mouse = win.getMouse()
        print("Point("+str(mouse.getX())+", "+str(mouse.getY())+")")

def playHangman():
    win = hangmanGUI()
    #getPoints(win)
    file = introTextAndFile(win)
    wordList = readWordList(file)
    secretWord = randomWordPicked(wordList)
    guessedWordReturn(secretWord, win)
    

def main():
    playHangman()
    
main()
