# Lab7.py
# Name 1: Eduardo R Abreu
# Name 2: Zack E Bolt

def formatPractice(): 
    """
    Each print statement contains a variable enclosed in angle brackets.
    Replace the variables (including the brackets) with code so that the
    three statements print the output given below:
    """

    print("It’s raining {1} and {0}.".format("dogs", "cats"))
    #expected output:
    #It's raining cats and dogs

    print("{0:.2f} {1:.3f}".format(2.3, .4567))
    #expected output:
    #2.30 0.457

    print("Time left {0:>02}:{1:>05.2f}".format(3, 7.4589))
    #expected output:
    #Time left 03:07.46

def pigLatin():
    sentence = input("Enter the sentence to be translated: ")
    ay = "ay"
    words = sentence.split()
    for term in words:
        firstLetter = term[0].lower()
        remaining = term[1:].lower()
        print(remaining+firstLetter+ay, end = " ")

def numberWords():
    infileName = "rawWords.txt"
    infile = open(infileName, "r")

    outfileName = "numberedWords.txt"
    outfile = open(outfileName, "w")

    lineNumber = 1
    wordNumber = 0

    for line in infile:
        spaceSplit = line.split()
        for words in spaceSplit:
            
            print(str(lineNumber) + ". " + words, file = outfile)
            lineNumber += 1
            wordNumber += 1
            
    print("Data written to file...")
    
    infile.close()
    outfile.close()

def hourlyWages():
    wageIncrease = 1.65
    
    infileName = "hourlyWages.txt"
    infile = open(infileName, "r")

    outfileName = "newHourlyWages.txt"
    outfile = open(outfileName, "w")

    for line in infile:
        spaceSplit = line.split()
        firstName = spaceSplit[0]
        lastName = spaceSplit[1]
        hourlyWage = spaceSplit[2]
        numberOfHoursWorked = spaceSplit[3]

        newHourlyWage = eval(hourlyWage) + wageIncrease

        print("{0} {1} {2:.2f}".format(firstName, lastName, newHourlyWage), file = outfile)

    print("Data written to file...")
    
    outfile.close()
    inflie.close()

def encode():
    string = input("Sentence to encode: ")
    key = eval(input("Enter key value: "))

    for i in range(len(string)):
        ch = string[i]
        letter = chr(ord(ch)+key)
        print(letter, end = "")

def encodeBetter():
    alphabet = "abcdefghijklmnopqrstuvwxyz"

    string = input("Sentence to encode: ")
    key = eval(input("Enter key value: "))

    for i in range(len(string)):
        ch = string[i]
        letterLocation = alphabet.find(ch)
        newLocation = letterLocation + key
        ch = alphabet[newLocation%26]

        print(ch, end="")

def main():
    #formatPractice()
    #pigLatin()
    #numberWords()
    #hourlyWages()
    #encode()
    encodeBetter()
main()
