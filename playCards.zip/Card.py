#Card class.
class Card:
    #Constructor.
    def __init__(self, suit, value):
        #What each value is.
        self.faceValues = ["Ace", "Two", "Three", "Four", "Five", "Six",
                       "Seven", "Eight", "Nine", "Ten", "Jack", "Queen",
                       "King"]
        #List of valid suits.
        self.suitList = ["Spades", "Hearts", "Clubs", "Diamonds"]
        #Check for validity of the value.
        if type(value) == int and value <= len(self.faceValues):
            self.value = value
        else:
            #If not sets it to "Ace".
            self.value = 1
        #Creates suit variable.
        self.suit = suit
        #Check for validity of the suit.
        isValid = self.validSuit(suit)
        #Sets to "Spades" if False.
        if isValid == False:
            self.suit = self.suitList[0]
    #Suit getter.
    def getSuit(self):
        return self.suit
    #Value getter.
    def getValue(self):
        return self.value
    #Was the suit valid or not?
    def validSuit(self, suit):
        isValid = False
        if suit in self.suitList:
            isValid = True
        return isValid
    #Compares anotherCard with self.
    def compareTo(self, anotherCard):
        #Variable for self.
        card1 = self.getValue()
        #Variable for anotherCard.
        card2 = anotherCard.getValue()
        #Draw.
        if card1 == card2:
            return 0
        #Card1 wins without "Ace".
        elif card1 != 1 and card1 > card2:
            return 1
        #card1 wins with "Ace".
        elif card1 == 1 and card2 != 1:
            return 1
        #card1 loses without "Ace".
        elif card1 != 1 and card1 < card2:
            return -1
        #card1 loses with "Ace".
        elif card1 != 1 and card2 == 1:
            return -1
    #Prints a string when called.
    def __str__(self):
        #Find face based on value.
        faceVal = self.getValue()
        face = self.faceValues[faceVal - 1]
        #Find suit based on suit.
        suit = self.getSuit()
        #Out string.
        strOut = face + " of " + suit
        #Returns it.
        return strOut
