####################################################
#                                                  #
# Name: Eduardo R Abreu                            #
# playWar.py                                       #
#                                                  #
# Problem: This inherits from Card class.          #
#                                                  #
# Certification of Authenticity:                   #
# I certify that this lab is entirely my own work. #
#                                                  #
####################################################

#Imports the Card class.
from Card import *
    
#Main method.
def main():
    card1 = Card("Spades", 13)
    print(card1)
    
main()
